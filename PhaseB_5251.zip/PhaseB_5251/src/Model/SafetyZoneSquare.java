package Model;

import javax.swing.*;

public class SafetyZoneSquare {
    private JLabel label;

    public SafetyZoneSquare(JLabel label) {
        this.label = label;

    }
}
